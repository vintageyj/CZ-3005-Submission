from queue import PriorityQueue
from xmlrpc.client import MAXINT
from path_structure import PathStruct
import helper_functions as hf


def a_star(start: str, end: str, energy: int, coord: dict, cost: dict, dist: dict, G: dict, heuristicMultiplier: float) -> PathStruct:
    """ For Task 3
    Args:
        start (str): Source node
        end (str): Destination node
        energy (int): Allowed budget for power consumption
        coord (dict): Node coordination dictionary Coord
        cost (dict): Edge cost dictionary 
        dist (dict): Edge distance dictionary
        G (dict): Graph dictionary
        heuristicMultiplier (float): Multiplier for the heuristic function, default value = 1.0

    Returns:
        PathInfo: Object with attributes of the path
    """

    queue = PriorityQueue()
    # (score, (dist, cost, path))
    queue.put((0, (0, 0, list(start))))
    distHash = {start : 0}
    energyHash = {start : 0}

    while queue.not_empty:
        item = queue.get()
        curDist, curEnergy, curPath = item[-1]
        curScore = item[0]

        # curNode is the latest node in path taken so far
        curNode = curPath[-1]

        if curNode == end:
            pathStruct = PathStruct()
            pathStruct.path = curPath
            pathStruct.dist = hf.calcTotalDist(curPath, dist)
            pathStruct.energy = hf.calcTotalEnergy(curPath, cost)
            return pathStruct

        # not end, add to queue
        for neighbour in G[curNode]:
            newDist = curDist + dist[f"{curNode},{neighbour}"]

            newEnergy = curEnergy + cost[f"{curNode},{neighbour}"]

            if newEnergy > energy:
                continue
            
            if newDist < distHash.get(neighbour, MAXINT) or newEnergy < energyHash.get(neighbour, MAXINT):
                if newDist < distHash.get(neighbour, MAXINT):
                    distHash[neighbour] = newDist
                
                if newEnergy < energyHash.get(neighbour, MAXINT):
                    energyHash[neighbour] = newEnergy

                heuristics = hf.h(neighbour, end, coord) * heuristicMultiplier
                newScore = newDist + heuristics
                newPath = curPath.copy()
                newPath.append(neighbour)
                queue.put((newScore, (newDist, newEnergy, newPath)))


    return PathStruct()

