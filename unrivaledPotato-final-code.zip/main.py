from helper_functions import loadData
import task1
import task2
import task3
import time

# Import data files
coord, cost, dist, g = loadData()

# Constants
ENERGY_BUDGET = 287932
START_NODE = '1'
END_NODE = '50'

def task_1():
    start = time.process_time()
    path = task1.uniform_cost_search(START_NODE, END_NODE, cost, dist, g)
    timeTaken = time.process_time() - start
    path.print_path(1, timeTaken)
    return

def task_2():
    start = time.process_time()
    path = task2.uniform_cost_search(START_NODE, END_NODE, ENERGY_BUDGET, cost, dist, g)
    timeTaken = time.process_time() - start
    path.print_path(2, timeTaken)
    return

def task_3():
    start = time.process_time()
    path = task3.a_star(START_NODE, END_NODE, ENERGY_BUDGET, coord, cost, dist, g, 1.0)
    timeTaken = time.process_time() - start
    path.print_path(3, timeTaken)
    return

def run_tasks():
    task_1()
    task_2()
    task_3()

if __name__ == "__main__":
    run_tasks()
