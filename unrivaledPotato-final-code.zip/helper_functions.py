import json
from math import sqrt
import os

def loadData():

    my_path = os.path.abspath(os.path.dirname(__file__))

    # print("cwd: ", os.getcwd())
    
    path = os.path.join(my_path, "data/Coord.json")
    with open(path) as x:
        coord = json.load(x)
        x.close()

    path = os.path.join(my_path, "data/Cost.json")
    with open(path) as x:
        cost = json.load(x)
        x.close()

    path = os.path.join(my_path, "data/Dist.json")
    with open(path) as x:
        dist = json.load(x)
        x.close()

    path = os.path.join(my_path, "data/G.json")
    with open(path) as x:
        g = json.load(x)
        x.close()

    return coord, cost, dist, g

def calcTotalDist(path: list, dist: dict) -> float:
    totalDist = 0
    for i in range(len(path) - 1):
        totalDist += dist[f"{path[i]},{path[i+1]}"]
    return totalDist

def calcTotalEnergy(path: list, cost: dict) -> float:
    totalEnergy = 0
    for i in range(len(path) - 1):
        totalEnergy += cost[f"{path[i]},{path[i+1]}"]
    return totalEnergy

# TODO: REFACTOR h()
def h(source: str, dest: str, coord: dict) -> int:
    """ Calculates heuristic value for the a* search for task 3

    Args:
        source (str): Source node
        dest (str): Destination node
        coord (dict): Dictionary of coordinates of nodes

    Returns:
        int: Distance between source and destination node
    """

    source_coord = coord[source]
    dest_coord = coord[dest]

    dx = abs(source_coord[0] - dest_coord[0])
    dy = abs(source_coord[1] - dest_coord[1])

    return sqrt(dx**2 + dy**2)
