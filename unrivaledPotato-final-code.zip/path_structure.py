
class PathStruct:

    def __init__(self, path=[], dist=-1, energy=-1):
        self.path = path
        self.dist = dist
        self.energy = energy

    def print_path(self, taskNumber: int, timeTaken: float) -> None:
        print("\n==================================================")
        print(f"\nTask {taskNumber}:")
        print("\nShortest path:", "->".join(self.path))
        print("\nTime taken:", timeTaken)
        print("Shortest distance:", self.dist)
        print("Total energy cost:", self.energy)