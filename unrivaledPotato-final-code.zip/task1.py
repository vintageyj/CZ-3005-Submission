from queue import PriorityQueue
from path_structure import PathStruct
import helper_functions as hf


def uniform_cost_search(start: str, end: str, cost: dict, dist: dict, G: dict) -> PathStruct:
    """ For Task 1
    Args:
        start (str): Starting node
        end (str): Destination node
        cost (dict): Edge cost dictionary 
        dist (dict): Edge distance dictionary
        G (dict): Graph dictionary

    Returns:
        PathStruct: Object with attributes of the path
    """

    queue = PriorityQueue()

    # queue object: (path's distance, path)
    queue.put((0, [start]))

    visited = set()

    while queue.not_empty:
        item = queue.get()

        curPath = item[1]

        # curNode is the latest node in path taken so far
        curNode = curPath[-1]

        if curNode not in visited:
            visited.add(curNode)

            if curNode == end:
                pathStruct = PathStruct()
                pathStruct.path = curPath
                pathStruct.dist = hf.calcTotalDist(curPath, dist)
                pathStruct.energy = hf.calcTotalEnergy(curPath, cost)
                return pathStruct

            # not end, add to queue
            for neighbour in G[curNode]:
                newDist = dist[f"{curNode},{neighbour}"]
                curDist = item[0] + newDist

                newPath = list(item[1])
                newPath.append(neighbour)

                queue.put((curDist, newPath))

    return PathStruct()
