from queue import PriorityQueue
from xmlrpc.client import MAXINT
from path_structure import PathStruct
import helper_functions as hf


def uniform_cost_search(start: str, end: str, energy: int, cost: dict, dist: dict, G: dict) -> PathStruct:
    """ For Task 2
    Args:
        start (str): Source node
        end (str): Destination node
        energy (int): Allowed budget for power consumption
        cost (dict): Edge cost dictionary 
        dist (dict): Edge distance dictionary
        G (dict): Graph dictionary

    Returns:
        PathInfo: Object with attributes of the path
    """

    queue = PriorityQueue()
    # (dist, (cost, path))
    queue.put((0, (0, list(start))))
    distHash = {start : 0}
    energyHash = {start : 0}

    while queue.not_empty:
        item = queue.get()
        curEnergy, curPath = item[-1]
        curDist = item[0]

        # curNode is the latest node in path taken so far
        curNode = curPath[-1]

        if curNode == end:
            pathStruct = PathStruct()
            pathStruct.path = curPath
            pathStruct.dist = hf.calcTotalDist(curPath, dist)
            pathStruct.energy = hf.calcTotalEnergy(curPath, cost)
            return pathStruct

        # not end, add to queue
        for neighbour in G[curNode]:
            newDist = curDist + dist[f"{curNode},{neighbour}"]

            newEnergy = curEnergy + cost[f"{curNode},{neighbour}"]

            if newEnergy > energy:
                continue
            
            if newDist < distHash.get(neighbour, MAXINT) or newEnergy < energyHash.get(neighbour, MAXINT):
                if newDist < distHash.get(neighbour, MAXINT):
                    distHash[neighbour] = newDist
                
                if newEnergy < energyHash.get(neighbour, MAXINT):
                    energyHash[neighbour] = newEnergy

                newPath = curPath.copy()
                newPath.append(neighbour)
                queue.put((newDist, (newEnergy, newPath)))


    return PathStruct()

